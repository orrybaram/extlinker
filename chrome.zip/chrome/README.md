ext linker
======
